# R script wrapper to implement SCE-UA (Duan et al 1994) calibration of Thornthwait model (TW).
#
# Script calls: SCEoptim
#
# Created: Bureau of Reclamation   2012-12
#
# DISCLAIMER:
# This code is being made available for the purpose of calibrating the Thornthwaite
# hydrologic model (McCabe and Markstrom, 2007) by interested persons.   The U.S. 
# Department of Interior's Bureau of Reclamation believes the information to be correct 
# representations of published theoretical processes.  However, human 
# and mechanical errors remain possibilities. Therefore, the Bureau of Reclamation does not 
# guarantee the accuracy and robustness of the modeling tools.
# Also, Bureau of Reclamation, nor any of the sources of the information shall be 
# responsible for any errors or omissions, or for the use or results obtained from the use
# of this modeling tool.
#
# References:
# Duan, Q., Sorooshian, S., and Gupta, V.K. (1994). �Optimal use of the SCE-UA global 
#   optimization method for calibrating watershed models,� Journal of Hydrology, 158, 
#   pp 265-284.
# McCabe, G.J., and Markstrom, S.L., 2007, A monthly water-balance model driven by a
#   graphical user interface: U.S. Geological Survey Open-File report 2007-1088, 6 p.
#
####################################################################################

# install.packages(c("zoo","latticeExtra","polynom","car","Hmisc"))

# default - cleans workspace
rm(list=ls())

library(hydromad)

################################################################################################
### USER INPUTS ###

# base directory for calibration tool
dirpath="C:/Lab_2_Tuesday/"

#user defined directories
in_dir = paste(dirpath,"in/",sep="")
out_dir = paste(dirpath,"out/",sep="")
src_dir = paste(dirpath,"src/",sep="")

# functions to be called in this script
srclist=c("objective_fun.R", "assign_wy2flows_mon.R", "subset_monthly_flows.R", "wb.R","mm2cms.R")
nsrc=length(paste(src_dir,srclist,sep=""))
for(i in 1:nsrc){
  source(file.path(src_dir, srclist[i]))
}

### END USER INPUTS ###
##################################################################################################

#parse user input file
#
tmp		<- read.table('user_input.txt',sep = "", skip = 7, fill = TRUE)
basin	<- tmp[1,1]
xlat	<- tmp[1,2]
area	<- tmp[1,3]
weights	<- c(tmp[2,2],tmp[3,2],tmp[4,2])
wystart <- tmp[5,2]
wyend   <- tmp[6,2]
valwyst <- tmp[7,2]
valwyen <- tmp[8,2]

# read parameter range file (in order of whc, rfactor, xmeltcoeff, directfac, tsnow, train)
paramfl 		<- paste(in_dir,"parameter_ranges",sep="",collapse=NULL)
param_range_mat <- read.table(paramfl,skip=13)
param_lower 	<- param_range_mat[,2]
param_upper 	<- param_range_mat[,3]
par				<- param_range_mat[,4]

finpt<-paste(in_dir,basin,"_monthly_TP.txt",sep="",collapse=NULL)

print("  Call SCE...")
ans <-SCEoptim(objective_fun,par,
	basin,xlat,area,weights,wystart,wyend,src_dir,out_dir,finpt,
	lower=param_lower,upper=param_upper,
	control=list(fnscale=-1,maxit=10000,tolsteps=10,reltol=0.1,ncomplex=5))

optpar=ans$par	
print("  Optimal parameters:")
print(optpar)

#----------------------------------------------------------
#----------------------------------------------------------
#post-processing with optimal parameters
fout<-paste("out/streamflow_",basin,"_out.txt",sep="",collapse=NULL)
  
#run water balance with optimal parameters
tw <- wb(xlat,optpar[1],optpar[2],optpar[3],optpar[4],optpar[5],optpar[6],finpt)

yr<-tw[,1]
month<-tw[,2]
runoff<-tw[,11]
simflow <- mm2cms(yr,month,runoff,area)  #reads in year, month, ROtot
tw<-cbind(tw,simflow[,3])

#write optimal parameters to file
write("Optimal Parameters",fout,append=F)
write("------------------",fout,append=T)
line1=paste("Soil moisture storage capacity (mm)   = ",optpar[1],sep="")
line2=paste("Runoff factor                         = ",optpar[2],sep="")
line3=paste("Maximum melt rate                     = ",optpar[3],sep="")
line4=paste("Direct runoff factor                  = ",optpar[4],sep="")
line5=paste("Snow temperature threshold (degree C) = ",optpar[5],sep="")
line6=paste("Rain temperature threshold (degree C) = ",optpar[6],sep="")
modelpar=paste(line1,line2,line3,line4,line5,line6,sep="\n")
write(modelpar,fout,append=T)

#write stats
write("Simulation Statistics",fout,append=T)
write("---------------------",fout,append=T)

obsfl <- paste(out_dir,"streamflow.obs\\",basin,".obs.mon",sep="",collapse=NULL)
obsflow <- read.table(obsfl)
obj_func <- calcOBJfunc(obsflow,simflow,weights,wystart,wyend)
#assign wy to monthly flows
obs_mat_wy <- assign_wy2flows_mon(obsflow)
sim_mat_wy <- assign_wy2flows_mon(simflow)
#subset sim and obs to chosen years
obs_mat_sub <- subset_monthly_flows(obs_mat_wy)
sim_mat_sub <- subset_monthly_flows(sim_mat_wy)
#build data frames
obs_df <- data.frame(wy=obs_mat_sub[,1],mon=obs_mat_sub[,2],obs=obs_mat_sub[,3])
sim_df <- data.frame(wy=sim_mat_sub[,1],mon=sim_mat_sub[,2],sim=sim_mat_sub[,3])
# compute annual ts by water year
obs_wy<-aggregate(obs_df["obs"], by=obs_df[c("wy")], FUN=mean)
sim_wy<-aggregate(sim_df["sim"], by=sim_df[c("wy")], FUN=mean)

nse_mon <- nseStat(obs_df$obs, sim_df$sim, ref = NULL, p = 2, trans = NULL, negatives.ok = FALSE, na.action = na.pass)
line1=paste("Monthly Nash-Sutcliffe coefficient = ",nse_mon,sep="")

nse_wy <- nseStat(obs_wy$obs, sim_wy$sim, ref = NULL, p = 2, trans = NULL, negatives.ok = FALSE, na.action = na.pass)
line2=paste("Annual Nash-Sutcliffe coefficient = ",nse_wy,sep="")

cor_mon <- cor(obs_df$obs, sim_df$sim, method = "pearson")
line3=paste("Monthly correlation coefficient = ",cor_mon,sep="")
stats=paste(line1,line2,line3,sep="\n")
write(stats,fout,append=T)

#write water balance
write("Water Balance",fout,append=T)
write("-------------",fout,append=T)
header="Flag Year Month PET P P-PET SoilMoisture AET PET-AET SnowStorage Surplus ROtotalmm ROtotalcms"
write(header,fout,append=T)

#append flag column indicating whether year is part of calibration period or validation period 
# (0=none,1=cal,2=val)
#ifelse(((month==2 & yr%%4==0 & yr%%100!=0) | (month==2 & yr%%400==0)),29,days[month])
tmp<-cbind(tw[,1],tw[,2],tw[,12])
tmp2<-assign_wy2flows_mon(tmp)
flag<-matrix(0, length(tmp2[,1]))
colnames(flag) <- "Flag"

# add flag for calibration years
for(i in 1:length(tmp2[,1])){
  ifelse((tmp2[i,1]>=wystart & tmp2[i,1]<=wyend),flag[i]<-1,flag[i]<-0)
}
# add flag for validation years
for(i in 1:length(tmp2[,1])){
  ifelse((tmp2[i,1]>=valwyst & tmp2[i,1]<=valwyen),flag[i]<-2,flag[i])
}
outmat<-cbind(flag,tw)
write.table(outmat,fout,row.names=F,col.names=F,sep=" ",append=TRUE)

#make plots
sim_ts<-ts(sim_mat_sub[,3],frequency=12,start=c(head(sim_mat_sub[,1],1),head(sim_mat_sub[,2],1)))
obs_ts<-ts(obs_mat_sub[,3],frequency=12,start=c(head(obs_mat_sub[,1],1),head(obs_mat_sub[,2],1)))

plot(sim_ts,type="l",xlab="time",ylab="flow (cms)")
title(main=basin)
lines(obs_ts,col="blue")
legend("topright", c("Natural Flow","Simulated Flow"), lty = 1, col = c("blue","black"))
dev.print(pdf,paste(out_dir,"streamflow/",basin,"_plot.pdf",sep="",collapse=NULL))
dev.copy(png,file = paste(out_dir,"streamflow/",basin,"_plot.png",sep="",collapse=NULL),width = 11, height = 8.5, units = "in", res=600)
dev.off()